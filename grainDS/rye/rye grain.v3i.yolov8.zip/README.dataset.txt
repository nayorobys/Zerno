# rye grain > 2026-07-27 2:35pm
https://universe.roboflow.com/rays-workspace-0iw7d/rye-grain

Provided by a Roboflow user
License: CC BY 4.0

